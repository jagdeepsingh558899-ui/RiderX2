// RiderX Customer Engine: GPS + map pickup/drop + reverse geocoding + fare + Firestore booking
import { auth, db, collection, addDoc, serverTimestamp, onAuthStateChanged, query, where, onSnapshot, doc, updateDoc } from "../firebase/firebase-config.js";

let map, pickupMarker, dropMarker, userMarker;
let pickupCoords = null, dropCoords = null, currentRideId = null;
let selectedService = 'bike';
let currentUser = null;
const rates = { bike:{base:20}, cab:{base:50}, parcel:{base:30}, food:{base:25} };

const $ = id => document.getElementById(id);
function status(t, error=false) { const el=$('bookingStatus'); if(el){el.textContent=t; el.style.color=error?'#ff5252':'#FFD600';} }
function setField(id,value){ const el=$(id); if(el) el.value=value; }
function distanceKm(a,b){
  const R=6371, dLat=(b.lat-a.lat)*Math.PI/180, dLon=(b.lng-a.lng)*Math.PI/180;
  const x=Math.sin(dLat/2)**2 + Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dLon/2)**2;
  return R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));
}
function fare(){
  if(!pickupCoords||!dropCoords){ if($('fare')) $('fare').textContent='₹0'; return 0; }
  const km=distanceKm(pickupCoords,dropCoords); const h=new Date().getHours();
  const perKm=(h>=22||h<6)?11:(km>10?9:8);
  const total=Math.round(rates[selectedService].base + km*perKm);
  $('fare').textContent=`₹${total}`;
  return total;
}
async function address(lat,lng){
  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,{headers:{Accept:'application/json'}});
    if(!r.ok) throw new Error(); const d=await r.json(); return d.display_name || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  }catch{return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;}
}
function markerAt(type,lat,lng){
  const old=type==='pickup'?pickupMarker:dropMarker; if(old) map.removeLayer(old);
  const m=L.marker([lat,lng]).addTo(map).bindPopup(type==='pickup'?'Pickup':'Drop').openPopup();
  if(type==='pickup') pickupMarker=m; else dropMarker=m;
}
async function choosePoint(lat,lng){
  if(!pickupCoords){ pickupCoords={lat,lng}; markerAt('pickup',lat,lng); setField('pickupLocation','Finding pickup address…'); setField('pickup','Finding pickup address…'); status('Pickup selected'); setField('pickupLocation',await address(lat,lng)); setField('pickup',await address(lat,lng)); return; }
  if(!dropCoords){ dropCoords={lat,lng}; markerAt('drop',lat,lng); setField('dropoffLocation','Finding drop address…'); setField('drop','Finding drop address…'); const a=await address(lat,lng); setField('dropoffLocation',a); setField('drop',a); fare(); status('Drop selected • Fare calculated'); return; }
  // Third tap starts a fresh pickup/drop selection.
  pickupCoords={lat,lng}; dropCoords=null; markerAt('pickup',lat,lng); if(dropMarker){map.removeLayer(dropMarker);dropMarker=null;} const a=await address(lat,lng); setField('pickupLocation',a); setField('pickup',a); setField('dropoffLocation',''); setField('drop',''); fare(); status('New pickup selected • Tap map again for drop');
}
function initMap(){
  const el=$('map'); if(!el||typeof L==='undefined') return;
  map=L.map(el).setView([30.7333,76.7794],13);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
  map.on('click',e=>choosePoint(e.latlng.lat,e.latlng.lng));
  if(navigator.geolocation){ navigator.geolocation.getCurrentPosition(async p=>{const {latitude:lat,longitude:lng}=p.coords; userMarker=L.marker([lat,lng]).addTo(map).bindPopup('Your current location'); map.setView([lat,lng],15); if(!pickupCoords) await choosePoint(lat,lng);},()=>status('Tap the map to choose pickup location')); }
  setTimeout(()=>map.invalidateSize(),300);
}
function setupServices(){ document.querySelectorAll('.service').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.service').forEach(x=>x.classList.remove('active'));b.classList.add('active');selectedService=b.dataset.service||b.dataset.type||'bike';fare();status(`${selectedService.toUpperCase()} selected`);})); }
function setupManualInputs(){
  $('pickupLocation')?.addEventListener('input',()=>{ if(!$('pickupLocation').value.trim()) pickupCoords=null; });
  $('dropoffLocation')?.addEventListener('input',()=>{ if(!$('dropoffLocation').value.trim()) dropCoords=null; });
  $('pickup')?.addEventListener('input',()=>{if(!$('pickup').value.trim())pickupCoords=null;});
  $('drop')?.addEventListener('input',()=>{if(!$('drop').value.trim())dropCoords=null;});
}
async function book(){
  if(!currentUser){location.replace('../auth/login.html');return;}
  const pickup=($('pickupLocation')?.value||$('pickup')?.value||'').trim(); const drop=($('dropoffLocation')?.value||$('drop')?.value||'').trim();
  if(!pickupCoords||!dropCoords||!pickup||!drop){status('Select Pickup and Drop on the map first.',true); return;}
  const btn=$('bookRide'); if(btn){btn.disabled=true;btn.textContent='Searching Rider…';}
  try{
    const otp=String(Math.floor(1000+Math.random()*9000)); const ride={customerId:currentUser.uid,pickupLocation:pickup,dropLocation:drop,pickupCoords,dropCoords,serviceType:selectedService,paymentMethod:$('paymentMethod')?.value||$('payment')?.value||'cash',fare:fare(),status:'REQUESTED',otp,city:'Chandigarh',createdAt:serverTimestamp()};
    const ref=await addDoc(collection(db,'rides'),ride); currentRideId=ref.id; status(`Searching nearby RiderX riders… • OTP ${otp}`); localStorage.setItem('riderx_active_ride',ref.id); localStorage.setItem('riderx_ride_otp',otp); listenRide(ref.id);
  }catch(e){status(e.message||'Booking failed.',true);} finally {if(btn){btn.disabled=false;btn.innerHTML='🚕 Book Ride';}}
}
function listenRide(id){
  onSnapshot(doc(db,'rides',id),snap=>{if(!snap.exists())return;const r=snap.data(); const names={REQUESTED:'Searching RiderX riders…',ACCEPTED:'Rider accepted your ride 🚀',ARRIVED:'Rider has arrived 📍',STARTED:'Trip started 🏍️',COMPLETED:'Trip completed ✅',CANCELLED:'Ride cancelled'}; status(names[r.status]||r.status); if(r.status==='ACCEPTED'&&r.riderId) localStorage.setItem('riderx_rider_id',r.riderId);});
}
function startExistingRide(){const id=localStorage.getItem('riderx_active_ride'); if(id){currentRideId=id;listenRide(id);}}
function setupBottom(){
  const items=document.querySelectorAll('.bottom div'); const routes=['home.html','history.html','wallet.html','profile.html']; items.forEach((x,i)=>x.addEventListener('click',()=>location.href=routes[i]||'home.html'));
  $('bookRide')?.addEventListener('click',book);
}
onAuthStateChanged(auth,user=>{currentUser=user;if(!user){location.replace('../auth/login.html');return;} initMap();setupServices();setupManualInputs();setupBottom();startExistingRide();});
