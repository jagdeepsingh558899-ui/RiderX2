// RiderX Authentication + Route Guard (Firebase v10.8.0)
import { auth, db, signOut, onAuthStateChanged, doc, getDoc } from "../firebase/firebase-config.js";
import { signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const path = window.location.pathname;
const isAuthPage = path.includes('/auth/');
const isProtected = /\/(customer|rider|admin)\//.test(path);

function go(role, approved, status) {
  if (role === 'admin') return location.replace('../admin/dashboard.html');
  if (role === 'rider') return location.replace(approved === true && status === 'active' ? '../rider/home.html' : '../rider/pending.html');
  return location.replace('../customer/home.html');
}

async function getRole(uid) {
  const snap = await getDoc(doc(db, 'users', uid));
  if (!snap.exists()) return null;
  return snap.data();
}

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('email')?.value.trim();
  const password = document.getElementById('password')?.value;
  const msg = document.getElementById('error-message') || document.getElementById('message');
  const btn = document.getElementById('login-btn');
  if (!email || !password) return;
  try {
    if (btn) { btn.disabled = true; btn.textContent = 'Logging in...'; }
    if (msg) { msg.style.display = 'block'; msg.textContent = 'Logging in...'; }
    const cred = await signInWithEmailAndPassword(auth, email, password);
    const data = await getRole(cred.user.uid);
    if (!data) throw new Error('Account profile not found. Please register again.');
    if (msg) msg.textContent = 'Login successful';
    go(data.role || 'customer', data.approved, data.status);
  } catch (err) {
    if (msg) { msg.style.display = 'block'; msg.textContent = friendlyAuthError(err); }
    if (btn) { btn.disabled = false; btn.textContent = 'Login'; }
  }
}

function friendlyAuthError(error) {
  const code = error?.code || '';
  const map = {
    'auth/invalid-credential':'Invalid email or password.',
    'auth/user-not-found':'No account found with this email.',
    'auth/wrong-password':'Invalid email or password.',
    'auth/invalid-email':'Please enter a valid email.',
    'auth/too-many-requests':'Too many attempts. Please try again later.',
    'auth/network-request-failed':'Network error. Check your internet connection.'
  };
  return map[code] || error.message || 'Login failed.';
}

const form = document.getElementById('login-form') || document.getElementById('loginForm');
if (form) form.addEventListener('submit', handleLogin);

onAuthStateChanged(auth, async user => {
  if (user) {
    if (isAuthPage || path.endsWith('/index.html') || path === '/') {
      try {
        const data = await getRole(user.uid);
        if (data) go(data.role || 'customer', data.approved, data.status);
      } catch (e) { console.error('Role lookup failed', e); }
    }
  } else if (isProtected) {
    const prefix = path.includes('/admin/') || path.includes('/rider/') || path.includes('/customer/') ? '../auth/login.html' : './auth/login.html';
    location.replace(prefix);
  }
});

export async function logoutUser() {
  await signOut(auth);
  location.replace('../auth/login.html');
}
