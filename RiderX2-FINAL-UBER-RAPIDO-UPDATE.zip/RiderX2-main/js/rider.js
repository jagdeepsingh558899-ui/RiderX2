// RiderX Rider Engine: online status + live requests + accept/reject + OTP + trip lifecycle
import { auth, db, onAuthStateChanged, doc, getDoc, updateDoc, collection, query, where, onSnapshot, serverTimestamp, runTransaction } from "../firebase/firebase-config.js";
let rider=null, online=false, activeRideId=null, unsubscribe=null, requestsUnsub=null;
const $=id=>document.getElementById(id);
function msg(t){if($('rideStatus'))$('rideStatus').textContent=t;}
function distance(a,b){if(!a||!b)return 999;const R=6371,d1=(b.lat-a.lat)*Math.PI/180,d2=(b.lng-a.lng)*Math.PI/180,x=Math.sin(d1/2)**2+Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(d2/2)**2;return R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));}
async function toggleOnline(){
 if(!rider)return; online=!online; await updateDoc(doc(db,'users',rider.uid),{isOnline:online,lastOnlineAt:serverTimestamp()}); await updateDoc(doc(db,'drivers',rider.uid),{isOnline:online});
 const b=$('onlineBtn');if(b){b.textContent=online?'🔴 Go Offline':'🟢 Go Online';b.style.background=online?'#ff4444':'#FFD600';b.style.color=online?'#fff':'#000';} if(online)listenRequests();else{requestsUnsub?.();requestsUnsub=null;msg('You are offline');}
}
function listenRequests(){
 requestsUnsub?.(); const q=query(collection(db,'rides'),where('status','==','REQUESTED'));
 requestsUnsub=onSnapshot(q,snap=>{let nearest=null,best=Infinity; snap.forEach(s=>{const r=s.data();const d=distance(window.__riderLocation,r.pickupCoords);if(d<best&&d<=15){best=d;nearest={id:s.id,...r};}});renderRequest(nearest);},e=>msg('Ride requests error: '+e.message));
}
function renderRequest(r){
 if(!$('customerName'))return; if(!r){$('customerName').textContent='Customer: No nearby request';$('pickupText').textContent='Pickup: —';$('dropText').textContent='Drop: —';$('fareText').textContent='Fare: —';return;}
 activeRideId=r.id;$('customerName').textContent='Customer: Ride request';$('pickupText').textContent='Pickup: '+r.pickupLocation;$('dropText').textContent='Drop: '+r.dropLocation;$('fareText').textContent='Fare: ₹'+r.fare+' • '+(r.paymentMethod||'cash');
 $('acceptRide').onclick=()=>acceptRide(r.id);$('rejectRide').onclick=()=>rejectRide(r.id);
}
async function acceptRide(id){
 try{await runTransaction(db,async tx=>{const ref=doc(db,'rides',id);const snap=await tx.get(ref);if(!snap.exists()||snap.data().status!=='REQUESTED')throw new Error('Ride was already accepted.');tx.update(ref,{status:'ACCEPTED',riderId:rider.uid,acceptedAt:serverTimestamp()});});activeRideId=id;listenRide(id);msg('Ride accepted 🚀');}catch(e){msg(e.message);}
}
async function rejectRide(id){if(activeRideId===id)activeRideId=null;msg('Ride request skipped');}
function listenRide(id){unsubscribe?.();unsubscribe=onSnapshot(doc(db,'rides',id),snap=>{if(!snap.exists())return;const r=snap.data();msg('Ride status: '+r.status);if($('startRide'))$('startRide').onclick=()=>startRide(id,r.otp);if($('completeRide'))$('completeRide').onclick=()=>completeRide(id);});}
async function startRide(id,otp){try{const snap=await getDoc(doc(db,'rides',id));const r=snap.data();if(r.otp&&String(r.otp)!==String($('otpInput')?.value||''))return msg('Invalid customer OTP');await updateDoc(doc(db,'rides',id),{status:'STARTED',startedAt:serverTimestamp()});msg('Trip started 🏍️');}catch(e){msg(e.message);}}
async function completeRide(id){try{await updateDoc(doc(db,'rides',id),{status:'COMPLETED',completedAt:serverTimestamp()});msg('Trip completed ✅');activeRideId=null;}catch(e){msg(e.message);}}
function trackLocation(){if(!navigator.geolocation)return;navigator.geolocation.watchPosition(async p=>{window.__riderLocation={lat:p.coords.latitude,lng:p.coords.longitude};if(rider){try{await updateDoc(doc(db,'drivers',rider.uid),{location:window.__riderLocation,lastLocationAt:serverTimestamp()});}catch{}}},{enableHighAccuracy:true,maximumAge:5000});}
onAuthStateChanged(auth,async u=>{if(!u){location.replace('../auth/login.html');return;}rider=u;trackLocation();try{const s=await getDoc(doc(db,'users',u.uid));if(!s.exists()||s.data().role!=='rider'){location.replace('../customer/home.html');return;}if(s.data().approved!==true||s.data().status!=='active'){location.replace('pending.html');return;}$('onlineBtn')?.addEventListener('click',toggleOnline);$('startRide')?.addEventListener('click',()=>activeRideId&&startRide(activeRideId));$('completeRide')?.addEventListener('click',()=>activeRideId&&completeRide(activeRideId));}catch(e){msg(e.message);}});
