// =====================================
// RiderX Firebase Messaging Setup
// =====================================

import {
  app,
  auth,
  db
} from "./config.js";

import {
  getMessaging,
  getToken,
  onMessage
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-messaging.js";

import {
  doc,
  setDoc
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const messaging = getMessaging(app);

// =====================================
// REQUEST NOTIFICATION PERMISSION
// =====================================

export async function enableNotification() {

  try {

    const permission = await Notification.requestPermission();

    if (permission === "granted") {

      const token = await getToken(messaging, {

        vapidKey: "BL9_-5Z7YfbA9iJsPj5SYF1PUSpTo2sCIoyL5cjBHOUOoQeDulTTznkqL_N-87z2MAKCfcEdY0PYA9Bdv48kd3g"

      });

      if (token) {

        await saveToken(token);

        console.log("FCM Token:", token);

      }

    } else {

      console.log("Notification Permission Denied");

    }

  } catch (error) {

    console.error("Notification Error:", error);

  }

}

// =====================================
// SAVE TOKEN
// =====================================

async function saveToken(token) {

  const user = auth.currentUser;

  if (!user) return;

  await setDoc(
    doc(db, "users", user.uid),
    {
      notificationToken: token
    },
    {
      merge: true
    }
  );

}

// =====================================
// FOREGROUND MESSAGE
// =====================================

onMessage(messaging, (payload) => {

  console.log("Notification Received:", payload);

  if (payload.notification) {

    alert(
      `${payload.notification.title}\n\n${payload.notification.body}`
    );

  }

});

export { messaging };
